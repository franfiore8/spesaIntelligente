<?php
    require 'config.php';
    session_start();

    $codiceCarta = $_SESSION['codiceCarta'];
    $codiceScontrino = $_SESSION['codiceScontrino'];
    $sql = $pdo->prepare('SELECT scontrino.codiceScontrino, dataOra, importoTotale, nomeProdotto, prezzo, quantita FROM scontrino, prodotto, scontrino_prodotto where  scontrino.codiceScontrino = scontrino_prodotto.codiceScontrino and prodotto.codiceBarre = scontrino_prodotto.codiceBarre and scontrino.codiceCarta = :codiceCarta and scontrino.codiceScontrino = :codiceScontrino');
    $sql->bindParam(':codiceCarta', $codiceCarta);
    $sql->bindParam(':codiceScontrino', $codiceScontrino);
    $sql->execute();
    $ris = $sql->fetchAll();

   
if($_SERVER['REQUEST_METHOD'] === "POST"){

    $indirizzoDestinazione = $_POST['indirizzoDestinazione'];
    $citta = $_POST['nomeNegozio'];
    $sql = $pdo->prepare('SELECT codiceNegozio FROM punto_vendita where citta = :citta');
    $sql->bindParam(':citta', $citta);
    $sql->execute();
    $negozio = $sql->fetch();

    if(!$negozio){
        die("Negozio non trovato");
    }
    $codiceNegozio = $negozio['codiceNegozio'];

    $idStato = 1;
    $idCorriere = rand(1,3);
    $dataConsegna = date('Y-m-d');
    $fasciaOraria = "18:00-20:00";
    
    $sql = $pdo->prepare('INSERT INTO consegna(codiceScontrino, codiceNegozio, idStato, idCorriere, dataConsegna, fasciaOraria, indirizzoDestinazione) VALUES(:codiceScontrino, :codiceNegozio, :idStato, :idCorriere, :dataConsegna, :fasciaOraria, :indirizzoDestinazione)');
    $sql->bindParam(':codiceScontrino', $codiceScontrino);
    $sql->bindParam(':codiceNegozio', $codiceNegozio);
    $sql->bindParam(':idStato', $idStato);
    $sql->bindParam(':idCorriere', $idCorriere);
    $sql->bindParam(':dataConsegna', $dataConsegna);
    $sql->bindParam(':fasciaOraria', $fasciaOraria);
    $sql->bindParam(':indirizzoDestinazione', $indirizzoDestinazione);
    $sql->execute();

    unset($_SESSION['codiceScontrino']);

    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="it">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Dettaglio Ordine</title>

<style>

:root {
    --brand-green: #0D472E;
    --brand-orange: #E9661B;
}

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

body {
    background: linear-gradient(135deg, #eef2f3, #dfe9f3);
    padding: 40px 20px;
}

.container {
    max-width: 1000px;
    margin: auto;
}

.card {
    background: white;
    border-radius: 24px;
    padding: 35px;
    box-shadow: 0 10px 25px rgba(0,0,0,0.08);
    position: relative;
}

.card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 6px;
    background: linear-gradient(90deg, var(--brand-green), var(--brand-orange));
}

h2 {
    text-align: center;
    color: var(--brand-green);
    margin-bottom: 20px;
}

.info-box {
    display: flex;
    justify-content: space-between;
    align-items: center;
    background: #f8fafc;
    padding: 15px 20px;
    border-radius: 14px;
    margin-bottom: 20px;
    border: 1px solid #e5e7eb;
}

.info-box span {
    font-weight: 600;
}

table {
    width: 100%;
    border-collapse: collapse;
    border-radius: 16px;
    overflow: hidden;
}

th {
    background: var(--brand-green);
    color: white;
    padding: 14px;
}

td {
    padding: 14px;
    text-align: center;
    border-bottom: 1px solid #eee;
}

tr:hover {
    background: #f9fafb;
}

.footer {
    margin-top: 20px;
    background: linear-gradient(135deg, var(--brand-green), #145a3a);
    color: white;
    padding: 16px;
    border-radius: 14px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.footer .value {
    font-size: 20px;
    font-weight: bold;
}

form{
    margin-top:30px;
}

input[type="text"]{
    width:100%;
    padding:12px;
    border-radius:10px;
    border:1px solid #ccc;
    margin-bottom:15px;
}

input[type="submit"]{
    background:#0D472E;
    color:white;
    border:none;
    padding:12px 20px;
    border-radius:10px;
    cursor:pointer;
    font-weight:bold;
}

input[type="submit"]:hover{
    background:#145a3a;
}

</style>

</head>

<body>

<div class="container">

<div class="card">

<h2>📦 Riepilogo Ordine</h2>

<?php if(count($ris) > 0): ?>

<div class="info-box">
    <span>🧾 Scontrino #<?= $ris[0]['codiceScontrino'] ?></span>
    <span><?= $ris[0]['dataOra'] ?></span>
</div>

<table>

    <tr>
        <th>Prodotto</th>
        <th>Prezzo</th>
        <th>Quantità</th>
    </tr>

    <?php foreach($ris as $el): ?>

    <tr>
        <td><?= $el['nomeProdotto'] ?></td>
        <td><?= $el['prezzo'] ?> €</td>
        <td><?= $el['quantita'] ?></td>
    </tr>

    <?php endforeach; ?>

</table>

<div class="footer">
    <div>💰 Totale ordine</div>
    <div class="value"><?= $ris[0]['importoTotale'] ?> €</div>
</div>

<?php else: ?>

<div style="text-align:center; padding:20px;">
    Nessun ordine trovato
</div>

<?php endif; ?>


<form method="post">

    <input 
        type="text"
        name="indirizzoDestinazione"
        placeholder="Inserisci indirizzo di consegna"
        required
    >

    <select 
    name="nomeNegozio"
    required
    style="
        width:100%;
        padding:12px;
        border-radius:10px;
        border:1px solid #ccc;
        margin-bottom:15px;
    "
>

    <option value="">Seleziona negozio</option>

    <option value="Milano">Milano</option>
    <option value="Monza">Monza</option>
    <option value="Bergamo">Bergamo</option>
    <option value="Como">Como</option>

</select>

    <input 
        type="submit"
        value="Conferma ordine"
    >

</form>

</div>

</div>

</body>
</html>