<?php
    require 'config.php';
    session_start();

    if (!isset($_SESSION['codiceCarta'])) {
        header("Location: login.php");
        exit;
    }

    $codiceCarta = $_SESSION['codiceCarta'];
    $codiceScontrino = $_SESSION['codiceScontrino'];

    $sql = $pdo->prepare('SELECT prodotto.codiceBarre, nomeProdotto, descrizione, prezzo, nomeReparto, numeroCorsia FROM prodotto, reparto where reparto.codiceReparto = prodotto.codiceReparto');
    $sql->execute();
    $ris = $sql->fetchAll();

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {

        $codiceBarre = $_POST['codiceBarre'] ?? '';
        $quantita = $_POST['quantita'] ?? 1;

        $sql = $pdo->prepare('INSERT INTO scontrino_prodotto (codiceScontrino, codiceBarre, quantita) VALUES (:codiceScontrino, :codiceBarre, :quantita) ON DUPLICATE KEY UPDATE quantita = quantita + VALUES(quantita)');
        $sql->bindParam(':codiceScontrino', $codiceScontrino);
        $sql->bindParam(':codiceBarre', $codiceBarre);
        $sql->bindParam(':quantita', $quantita);
        $sql->execute();

        $sql = $pdo->prepare('SELECT prezzo FROM prodotto where codiceBarre = :codiceBarre');
        $sql->bindParam(':codiceBarre', $codiceBarre);
        $sql->execute();

        $prodotto = $sql->fetch();
        $totaleDaAggiungere = $prodotto['prezzo'] * $quantita;

        $sql = $pdo->prepare('UPDATE scontrino SET importoTotale = importoTotale + :totale where codiceScontrino = :codiceScontrino');

        $sql->bindParam(':totale', $totaleDaAggiungere);
        $sql->bindParam(':codiceScontrino', $codiceScontrino);
        $sql->execute();

        header("Location: shop.php");
        exit;
    }
?>
<!DOCTYPE html>
<html lang="it">
<head>
<meta charset="UTF-8">
<title>Shop - SpesaIntelligente</title>

<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

body{
    background:linear-gradient(135deg, #eef2f3, #dfe9f3);
    padding:25px;
    color:#1f2937;
}

/* TOP BAR */
.top-bar{
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:25px;
}

.top-bar a{
    background:#0D472E;
    color:white;
    padding:12px 18px;
    border-radius:10px;
    text-decoration:none;
    font-weight:600;
    transition:0.25s;
}

.top-bar a:hover{
    background:#0a3522;
    transform:translateY(-2px);
}

/* LOGOUT */
.top-bar form{
    margin:0;
}

.top-bar button{
    background:#b91c1c;
    color:white;
    border:none;
    padding:12px 18px;
    border-radius:10px;
    cursor:pointer;
    font-weight:600;
    transition:0.25s;
}

.top-bar button:hover{
    background:#991b1b;
    transform:translateY(-2px);
}

/* TITLE */
h2{
    margin-bottom:15px;
    color:#0D472E;
}

/* TABLE */
table{
    width:100%;
    border-collapse:collapse;
    background:white;
    border-radius:16px;
    overflow:hidden;
    box-shadow:0 10px 25px rgba(0,0,0,0.08);
}

th{
    background:#0D472E;
    color:white;
    padding:14px;
    font-size:14px;
}

td{
    padding:14px;
    text-align:center;
    border-bottom:1px solid #eee;
    font-size:14px;
}

tr:hover{
    background:#f9fafb;
}

/* FORM IN TABELLA */
td form{
    display:flex;
    justify-content:center;
    align-items:center;
    gap:10px;
}

/* INPUT */
input{
    width:70px;
    padding:6px;
    border:1px solid #d1d5db;
    border-radius:8px;
    text-align:center;
}

/* BUTTON BASE */
button{
    border:none;
    padding:8px 14px;
    border-radius:10px;
    cursor:pointer;
    color:white;
    font-weight:600;
    transition:0.25s;
}

/* AGGIUNGI */
.add-btn{
    background:#E9661B;
}

.add-btn:hover{
    background:#cc5713;
    transform:translateY(-2px);
}
</style>
</head>

<body>

<div class="top-bar">

    <a href="order.php">Vai al carrello</a>

    <form action="logout.php" method="POST">
        <button type="submit">🚪 Logout</button>
    </form>

</div>

<h2>🛒 SHOP PRODOTTI</h2>

<table>
<thead>
<tr>
    <th>Prodotto</th>
    <th>Descrizione</th>
    <th>Prezzo</th>
    <th>Reparto</th>
    <th>Corsia</th>
    <th>Quantità</th>
</tr>
</thead>

<tbody>

<?php foreach($ris as $el): ?>
<tr>
    <td><?= $el['nomeProdotto'] ?></td>
    <td><?= $el['descrizione'] ?></td>
    <td><?= $el['prezzo'] ?> €</td>
    <td><?= $el['nomeReparto'] ?></td>
    <td><?= $el['numeroCorsia'] ?></td>

    <td>
        <form method="POST">
            <input type="hidden" name="codiceBarre" value="<?= $el['codiceBarre'] ?>">
            <input type="number" name="quantita" min="1" value="1">
            <button type="submit" class="add-btn">Aggiungi</button>
        </form>
    </td>
</tr>
<?php endforeach; ?>

</tbody>
</table>

</body>
</html>