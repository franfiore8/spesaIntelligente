<?php
require 'config.php';
session_start();

if (!isset($_SESSION['codiceCarta'])) {
    header("Location: login.php");
    exit;
}

$codiceCarta = $_SESSION['codiceCarta'];

if (!isset($_SESSION['codiceScontrino'])) {

    $nCassa = rand(1, 5);
    $sql = $pdo->prepare('INSERT INTO scontrino (codiceCarta, dataOra, numeroCassa, importoTotale) VALUES (:codiceCarta, NOW(), :numeroCassa, 0)');

    $sql->bindParam(':codiceCarta', $codiceCarta);
    $sql->bindParam(':numeroCassa', $nCassa);
    $sql->execute();
    $_SESSION['codiceScontrino'] = $pdo->lastInsertId();
}
$codiceScontrino = $_SESSION['codiceScontrino'];

if ($_SERVER['REQUEST_METHOD'] === "POST") {
    $sql = $pdo->prepare('DELETE FROM scontrino where codiceScontrino = :codiceScontrino');
    $sql->bindParam(':codiceScontrino', $codiceScontrino);
    $sql->execute();

    unset($_SESSION['codiceScontrino']);
    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Carrello - SpesaIntelligente</title>

    <style>
    *{
        margin:0;
        padding:0;
        box-sizing:border-box;
    }

    body{
        font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background:linear-gradient(135deg, #eef2f3, #dfe9f3);
        display:flex;
        justify-content:center;
        align-items:center;
        min-height:100vh;
    }

    .box{
        width:420px;
        background:#ffffff;
        padding:40px 35px;
        border-radius:22px;
        text-align:center;
        box-shadow:0 12px 35px rgba(0,0,0,0.12);
        animation:fadeIn 0.4s ease-in-out;
    }

    @keyframes fadeIn{
        from{
            opacity:0;
            transform:translateY(20px);
        }
        to{
            opacity:1;
            transform:translateY(0);
        }
    }

    h1{
        color:#0D472E;
        font-size:28px;
        margin-bottom:15px;
    }

    p{
        color:#555;
        font-size:15px;
        margin:8px 0;
    }

    strong{
        color:#111;
    }

    .id-box{
        margin-top:20px;
        background:#f5f7fa;
        border:1px solid #e2e8f0;
        padding:15px;
        border-radius:12px;
    }

    .btn-container{
        margin-top:25px;
        display:flex;
        flex-direction:column;
        gap:12px;
    }

    a,
    input[type="submit"]{
        width:100%;
        padding:14px;
        border:none;
        border-radius:14px;
        font-size:15px;
        font-weight:600;
        cursor:pointer;
        transition:all 0.25s ease;
        text-decoration:none;
        display:inline-block;
    }
s
    a{
        background:#0D472E;
        color:white;
    }

    a:hover{
        background:#0a3522;
        transform:translateY(-2px);
    }

    input[type="submit"]{
        background:#E9661B;
        color:white;
    }

    input[type="submit"]:hover{
        background:#cc5713;
        transform:translateY(-2px);
    }
</style>
</head>

<body>

<div class="box">
    <h1>🛒 Carrello Attivo</h1>

    <p>Il tuo scontrino è stato creato o recuperato.</p>

    <p>
        <strong>ID Scontrino:</strong>
        <?= $codiceScontrino ?>
    </p>

    <a href="shop.php">Vai ai prodotti</a>

    <form method="POST">
        <input type="submit" value="Annulla modifiche">
    </form>
</div>

</body>
</html>