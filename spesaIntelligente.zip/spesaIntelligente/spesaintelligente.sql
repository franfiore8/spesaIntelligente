-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Creato il: Mag 12, 2026 alle 17:06
-- Versione del server: 10.4.32-MariaDB
-- Versione PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `spesaintelligente`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `cliente`
--

CREATE TABLE `cliente` (
  `codiceCarta` varchar(10) NOT NULL,
  `cognome` varchar(50) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `dataIscrizione` date NOT NULL,
  `saldoPunti` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `cliente`
--

INSERT INTO `cliente` (`codiceCarta`, `cognome`, `nome`, `pass`, `email`, `telefono`, `dataIscrizione`, `saldoPunti`) VALUES
('BL2838', 'Bianchi', 'Luca', '$2y$10$4wbPXjocNPTQ2i7xboUpcOvrfwVFQmz7zIj68V64xDFwXxURcBYOC', 'luca.bianchi@gmail.com', '4324234234', '2026-05-12', 0),
('FF2452', 'Fiore', 'Francesco', '$2y$10$VLSCU7tik/R8HQEq3.H1xeRclvf/NL8G7fLuVNFMoYn82EuFW3BrW', 'tffiorefran@gmail.com', '3424324234', '2026-05-12', 0),
('RM1356', 'Rossi', 'Mario', '$2y$10$mh0mWtIam0KdXwpWjzGbzO6nVa66QDtbDenFrKfyuerUJ62CltFzm', 'mario.rossi@gmail.com', '3242343214', '2026-05-12', 0);

-- --------------------------------------------------------

--
-- Struttura della tabella `consegna`
--

CREATE TABLE `consegna` (
  `codiceConsegna` int(11) NOT NULL,
  `codiceScontrino` int(11) NOT NULL,
  `codiceNegozio` int(11) NOT NULL,
  `idCorriere` int(11) NOT NULL,
  `idStato` int(11) NOT NULL,
  `dataConsegna` date DEFAULT NULL,
  `fasciaOraria` varchar(30) DEFAULT NULL,
  `indirizzoDestinazione` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `consegna`
--

INSERT INTO `consegna` (`codiceConsegna`, `codiceScontrino`, `codiceNegozio`, `idCorriere`, `idStato`, `dataConsegna`, `fasciaOraria`, `indirizzoDestinazione`) VALUES
(7, 1, 1, 2, 1, '2026-05-12', '18:00 - 20:00', 'Via Roma 10'),
(8, 2, 2, 1, 2, '2026-05-12', '10:00 - 12:00', 'Via Milano 22'),
(9, 3, 1, 3, 1, '2026-05-13', '14:00 - 16:00', 'Via Torino 5'),
(10, 4, 2, 2, 2, '2026-05-13', '16:00 - 18:00', 'Via Napoli 18'),
(11, 5, 1, 1, 1, '2026-05-14', '09:00 - 11:00', 'Via Venezia 7'),
(12, 25, 1, 2, 1, '2026-05-12', '18:00-20:00', 'dsadasda'),
(13, 26, 1, 1, 1, '2026-05-12', '18:00-20:00', 'dasfdsfsfs'),
(14, 27, 1, 1, 1, '2026-05-12', '18:00-20:00', 'dadsads');

-- --------------------------------------------------------

--
-- Struttura della tabella `corriere`
--

CREATE TABLE `corriere` (
  `idCorriere` int(11) NOT NULL,
  `cognome` varchar(50) NOT NULL,
  `nome` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `corriere`
--

INSERT INTO `corriere` (`idCorriere`, `cognome`, `nome`) VALUES
(1, 'Rossi', 'Mario'),
(2, 'Bianchi', 'Luca'),
(3, 'Verdi', 'Andrea');

-- --------------------------------------------------------

--
-- Struttura della tabella `prodotto`
--

CREATE TABLE `prodotto` (
  `codiceBarre` varchar(20) NOT NULL,
  `codiceReparto` int(11) NOT NULL,
  `nomeProdotto` varchar(100) NOT NULL,
  `descrizione` text DEFAULT NULL,
  `prezzo` decimal(8,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `prodotto`
--

INSERT INTO `prodotto` (`codiceBarre`, `codiceReparto`, `nomeProdotto`, `descrizione`, `prezzo`) VALUES
('800100000001', 1, 'Mele Golden', 'Mele fresche italiane', 2.50),
('800100000002', 1, 'Banane', 'Banane Ecuador', 1.90),
('800100000003', 1, 'Arance', 'Arance siciliane', 2.20),
('800100000004', 1, 'Pomodori', 'Pomodori ciliegino', 3.10),
('800100000005', 2, 'Petto di Pollo', 'Carne fresca di pollo', 8.90),
('800100000006', 2, 'Hamburger Bovino', 'Hamburger di manzo', 6.50),
('800100000007', 2, 'Salsiccia', 'Salsiccia fresca', 7.20),
('800100000008', 3, 'Pasta Barilla', 'Spaghetti 500g', 1.20),
('800100000009', 3, 'Riso Scotti', 'Riso 1kg', 2.80),
('800100000010', 3, 'Passata Pomodoro', 'Passata 700ml', 1.80),
('800100000011', 3, 'Olio EVO', 'Olio extravergine 1L', 7.90),
('800100000012', 3, 'Tonno in Scatola', 'Tonno 80g x4', 4.50),
('800100000013', 4, 'Pizza Surgelata', 'Pizza margherita', 3.50),
('800100000014', 4, 'Patatine Surgelate', 'Patatine 1kg', 2.90),
('800100000015', 4, 'Verdure Miste', 'Mix verdure surgelate', 2.40),
('800100000016', 5, 'Acqua Naturale', 'Bottiglia 1.5L', 0.50),
('800100000017', 5, 'Coca Cola', 'Lattina 330ml', 1.30),
('800100000018', 5, 'Succo Arancia', 'Succo 1L', 2.10),
('800100000019', 5, 'Birra Moretti', 'Birra 66cl', 1.80),
('800100000020', 6, 'Pane Integrale', 'Pane fresco', 2.00),
('800100000021', 6, 'Focaccia', 'Focaccia olio evo', 3.00),
('800100000022', 6, 'Croissant', 'Croissant crema', 1.50),
('800100000023', 7, 'Salmone Fresco', 'Filetto di salmone', 14.90),
('800100000024', 7, 'Gamberi', 'Gamberi freschi', 18.50),
('800100000025', 8, 'Tiramisu', 'Dolce italiano', 5.50),
('800100000026', 8, 'Gelato Vaniglia', 'Vaschetta 500g', 4.20);

-- --------------------------------------------------------

--
-- Struttura della tabella `punto_vendita`
--

CREATE TABLE `punto_vendita` (
  `codiceNegozio` int(11) NOT NULL,
  `indirizzo` varchar(150) NOT NULL,
  `citta` varchar(50) NOT NULL,
  `direttore` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `punto_vendita`
--

INSERT INTO `punto_vendita` (`codiceNegozio`, `indirizzo`, `citta`, `direttore`) VALUES
(1, 'Via Roma 15', 'Milano', 'Giuseppe Verdi'),
(2, 'Corso Torino 88', 'Milano', 'Laura Neri'),
(3, 'Via Dante 20', 'Monza', 'Alessandro Galli'),
(4, 'Via Napoli 44', 'Bergamo', 'Martina Sala'),
(5, 'Piazza Duomo 3', 'Como', 'Roberto Villa');

-- --------------------------------------------------------

--
-- Struttura della tabella `reparto`
--

CREATE TABLE `reparto` (
  `codiceReparto` int(11) NOT NULL,
  `nomeReparto` varchar(50) NOT NULL,
  `numeroCorsia` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `reparto`
--

INSERT INTO `reparto` (`codiceReparto`, `nomeReparto`, `numeroCorsia`) VALUES
(1, 'Ortofrutta', 1),
(2, 'Macelleria', 2),
(3, 'Alimentari', 3),
(4, 'Surgelati', 4),
(5, 'Bevande', 5),
(6, 'Panetteria', 6),
(7, 'Pescheria', 7),
(8, 'Dolci', 8);

-- --------------------------------------------------------

--
-- Struttura della tabella `scontrino`
--

CREATE TABLE `scontrino` (
  `codiceScontrino` int(11) NOT NULL,
  `codiceCarta` varchar(10) DEFAULT NULL,
  `dataOra` datetime NOT NULL,
  `numeroCassa` int(11) NOT NULL,
  `importoTotale` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `scontrino`
--

INSERT INTO `scontrino` (`codiceScontrino`, `codiceCarta`, `dataOra`, `numeroCassa`, `importoTotale`) VALUES
(1, 'BL2838', '2025-05-01 10:15:00', 2, 15.40),
(2, 'FF2452', '2025-05-02 18:20:00', 4, 28.70),
(3, 'RM1356', '2025-05-03 12:45:00', 1, 9.80),
(4, NULL, '2025-05-04 16:30:00', 3, 6.50),
(5, 'BL2838', '2025-05-05 11:10:00', 5, 42.90),
(6, 'FF2452', '2025-05-06 14:00:00', 1, 33.20),
(7, NULL, '2025-05-07 19:45:00', 6, 18.60),
(8, 'RM1356', '2025-05-08 09:30:00', 2, 55.10),
(9, 'BL2838', '2025-05-09 17:20:00', 4, 12.40),
(10, 'FF2452', '2025-05-10 20:00:00', 3, 72.80),
(25, 'FF2452', '2026-05-12 15:45:34', 5, 70.20),
(26, 'FF2452', '2026-05-12 17:01:52', 3, 20.00),
(27, 'FF2452', '2026-05-12 17:02:59', 1, 20.00);

-- --------------------------------------------------------

--
-- Struttura della tabella `scontrino_prodotto`
--

CREATE TABLE `scontrino_prodotto` (
  `codiceScontrino` int(11) NOT NULL,
  `codiceBarre` varchar(20) NOT NULL,
  `quantita` int(11) NOT NULL,
  `prezzoApplicato` decimal(8,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `scontrino_prodotto`
--

INSERT INTO `scontrino_prodotto` (`codiceScontrino`, `codiceBarre`, `quantita`, `prezzoApplicato`) VALUES
(1, '800100000001', 2, 2.50),
(1, '800100000008', 3, 1.20),
(1, '800100000016', 4, 0.50),
(2, '800100000005', 2, 8.90),
(2, '800100000013', 1, 3.50),
(2, '800100000017', 3, 1.30),
(3, '800100000002', 2, 1.90),
(3, '800100000010', 2, 1.80),
(4, '800100000016', 5, 0.50),
(4, '800100000017', 2, 1.30),
(5, '800100000011', 1, 7.90),
(5, '800100000020', 2, 2.00),
(5, '800100000023', 1, 14.90),
(5, '800100000025', 1, 5.50),
(6, '800100000003', 3, 2.20),
(6, '800100000006', 2, 6.50),
(6, '800100000018', 4, 2.10),
(7, '800100000019', 3, 1.80),
(7, '800100000021', 2, 3.00),
(7, '800100000022', 4, 1.50),
(8, '800100000014', 2, 2.90),
(8, '800100000024', 1, 18.50),
(8, '800100000026', 2, 4.20),
(9, '800100000004', 2, 3.10),
(9, '800100000009', 1, 2.80),
(9, '800100000016', 6, 0.50),
(10, '800100000005', 3, 8.90),
(10, '800100000011', 2, 7.90),
(10, '800100000023', 2, 14.90),
(10, '800100000025', 2, 5.50),
(25, '800100000001', 22, 0.00),
(25, '800100000002', 8, 0.00),
(26, '800100000001', 8, 0.00),
(27, '800100000001', 8, 0.00);

-- --------------------------------------------------------

--
-- Struttura della tabella `stato`
--

CREATE TABLE `stato` (
  `idStato` int(11) NOT NULL,
  `stato` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `stato`
--

INSERT INTO `stato` (`idStato`, `stato`) VALUES
(1, 'In preparazione'),
(2, 'In transito'),
(3, 'Consegnata'),
(4, 'Annullata');

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `cliente`
--
ALTER TABLE `cliente`
  ADD PRIMARY KEY (`codiceCarta`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indici per le tabelle `consegna`
--
ALTER TABLE `consegna`
  ADD PRIMARY KEY (`codiceConsegna`),
  ADD UNIQUE KEY `codiceScontrino` (`codiceScontrino`),
  ADD KEY `codiceNegozio` (`codiceNegozio`),
  ADD KEY `idStato` (`idStato`),
  ADD KEY `fk_consegna_corriere` (`idCorriere`);

--
-- Indici per le tabelle `corriere`
--
ALTER TABLE `corriere`
  ADD PRIMARY KEY (`idCorriere`);

--
-- Indici per le tabelle `prodotto`
--
ALTER TABLE `prodotto`
  ADD PRIMARY KEY (`codiceBarre`),
  ADD KEY `codiceReparto` (`codiceReparto`);

--
-- Indici per le tabelle `punto_vendita`
--
ALTER TABLE `punto_vendita`
  ADD PRIMARY KEY (`codiceNegozio`);

--
-- Indici per le tabelle `reparto`
--
ALTER TABLE `reparto`
  ADD PRIMARY KEY (`codiceReparto`);

--
-- Indici per le tabelle `scontrino`
--
ALTER TABLE `scontrino`
  ADD PRIMARY KEY (`codiceScontrino`),
  ADD KEY `codiceCarta` (`codiceCarta`);

--
-- Indici per le tabelle `scontrino_prodotto`
--
ALTER TABLE `scontrino_prodotto`
  ADD PRIMARY KEY (`codiceScontrino`,`codiceBarre`),
  ADD KEY `codiceBarre` (`codiceBarre`);

--
-- Indici per le tabelle `stato`
--
ALTER TABLE `stato`
  ADD PRIMARY KEY (`idStato`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `consegna`
--
ALTER TABLE `consegna`
  MODIFY `codiceConsegna` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT per la tabella `corriere`
--
ALTER TABLE `corriere`
  MODIFY `idCorriere` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT per la tabella `punto_vendita`
--
ALTER TABLE `punto_vendita`
  MODIFY `codiceNegozio` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT per la tabella `reparto`
--
ALTER TABLE `reparto`
  MODIFY `codiceReparto` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT per la tabella `scontrino`
--
ALTER TABLE `scontrino`
  MODIFY `codiceScontrino` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT per la tabella `stato`
--
ALTER TABLE `stato`
  MODIFY `idStato` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Limiti per le tabelle scaricate
--

--
-- Limiti per la tabella `consegna`
--
ALTER TABLE `consegna`
  ADD CONSTRAINT `consegna_ibfk_1` FOREIGN KEY (`codiceScontrino`) REFERENCES `scontrino` (`codiceScontrino`),
  ADD CONSTRAINT `consegna_ibfk_2` FOREIGN KEY (`codiceNegozio`) REFERENCES `punto_vendita` (`codiceNegozio`),
  ADD CONSTRAINT `consegna_ibfk_3` FOREIGN KEY (`idStato`) REFERENCES `stato` (`idStato`),
  ADD CONSTRAINT `fk_consegna_corriere` FOREIGN KEY (`idCorriere`) REFERENCES `corriere` (`idCorriere`);

--
-- Limiti per la tabella `prodotto`
--
ALTER TABLE `prodotto`
  ADD CONSTRAINT `prodotto_ibfk_1` FOREIGN KEY (`codiceReparto`) REFERENCES `reparto` (`codiceReparto`);

--
-- Limiti per la tabella `scontrino`
--
ALTER TABLE `scontrino`
  ADD CONSTRAINT `scontrino_ibfk_1` FOREIGN KEY (`codiceCarta`) REFERENCES `cliente` (`codiceCarta`);

--
-- Limiti per la tabella `scontrino_prodotto`
--
ALTER TABLE `scontrino_prodotto`
  ADD CONSTRAINT `scontrino_prodotto_ibfk_1` FOREIGN KEY (`codiceScontrino`) REFERENCES `scontrino` (`codiceScontrino`),
  ADD CONSTRAINT `scontrino_prodotto_ibfk_2` FOREIGN KEY (`codiceBarre`) REFERENCES `prodotto` (`codiceBarre`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
